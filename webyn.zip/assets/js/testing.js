// On sélectionne les éléments à modifier
const logo = document.querySelector('.d-block'); // Logo
const title = document.getElementsByTagName('h1')[1]; // Titre
const description = document.querySelector('.lead'); // Description
const button_left = document.querySelector('.btn-primary'); // Bouton gauche
const button_right = document.querySelector('.btn-outline-secondary'); // Bouton droite
const second_text = document.getElementsByTagName('h1')[2]; // Second titre
const third_text = document.getElementsByTagName('h1')[3]; // Troisième titre
var temp_text = ""; // Variable qui va stocker le texte du second titre

// On met à jour le logo
if (logo) {
    logo.src = 'assets/brand/logo-webyn.png'; // On le remplace par le bon
    logo.alt = 'New Logo';
    logo.width = 300;
    logo.height = 72;
}

// On met à jour le second titre avec le style
if (title) {
    title.innerHTML = 'Generate <span style="color: #0ea5e9;">more revenue</span> with your website!';
}

// On échange le second titre avec le troisième
if (second_text && third_text) {
    temp_text = second_text.innerHTML;
    second_text.innerHTML = third_text.innerHTML;
    third_text.innerHTML = temp_text;
}

// On met à jour la description
if (description) {
    description.textContent = 'Start optimizing your website today with our tools and strategies.';
}

// On met à jour les textes et styles des deux boutons
if (button_left) {
    button_left.textContent = 'Book a demo'; // Bouton de gauche
    button_left.style.borderRadius = '100px';
}

if (button_right) {
    button_right.textContent = 'Analyse my website →'; // Bouton de droite
    button_right.style.borderRadius = '100px';
}
